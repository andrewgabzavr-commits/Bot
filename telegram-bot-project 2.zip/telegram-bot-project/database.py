import asyncio
import time
from dataclasses import dataclass
from pathlib import Path

import aiosqlite


FREE_REQUESTS_PER_DAY = 3
DAY_SECONDS = 24 * 60 * 60


@dataclass(frozen=True)
class Balance:
    free_requests: int
    purchased_requests: int

    @property
    def total_requests(self) -> int:
        return self.free_requests + self.purchased_requests


class Database:
    def __init__(self, path: str) -> None:
        self.path = Path(path)
        self.connection: aiosqlite.Connection | None = None
        self._lock = asyncio.Lock()

    async def connect(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = await aiosqlite.connect(self.path)
        self.connection.row_factory = aiosqlite.Row
        await self.connection.execute("PRAGMA journal_mode = WAL")
        await self.connection.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                free_requests INTEGER NOT NULL DEFAULT 3,
                purchased_requests INTEGER NOT NULL DEFAULT 0,
                free_reset_at INTEGER NOT NULL
            )
            """
        )
        await self.connection.execute(
            """
            CREATE TABLE IF NOT EXISTS payments (
                telegram_payment_charge_id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                package_id TEXT NOT NULL,
                requests INTEGER NOT NULL,
                stars INTEGER NOT NULL,
                created_at INTEGER NOT NULL
            )
            """
        )
        await self.connection.commit()

    async def close(self) -> None:
        if self.connection is not None:
            await self.connection.close()
            self.connection = None

    def _require_connection(self) -> aiosqlite.Connection:
        if self.connection is None:
            raise RuntimeError("Database is not connected")
        return self.connection

    async def _ensure_user_locked(
        self,
        user_id: int,
        now: int,
    ) -> aiosqlite.Row:
        connection = self._require_connection()
        cursor = await connection.execute(
            """
            SELECT user_id, free_requests, purchased_requests, free_reset_at
            FROM users
            WHERE user_id = ?
            """,
            (user_id,),
        )
        row = await cursor.fetchone()
        await cursor.close()

        if row is None:
            await connection.execute(
                """
                INSERT INTO users (
                    user_id, free_requests, purchased_requests, free_reset_at
                )
                VALUES (?, ?, 0, ?)
                """,
                (user_id, FREE_REQUESTS_PER_DAY, now + DAY_SECONDS),
            )
        elif now >= row["free_reset_at"]:
            await connection.execute(
                """
                UPDATE users
                SET free_requests = ?, free_reset_at = ?
                WHERE user_id = ?
                """,
                (FREE_REQUESTS_PER_DAY, now + DAY_SECONDS, user_id),
            )

        cursor = await connection.execute(
            """
            SELECT user_id, free_requests, purchased_requests, free_reset_at
            FROM users
            WHERE user_id = ?
            """,
            (user_id,),
        )
        updated_row = await cursor.fetchone()
        await cursor.close()
        if updated_row is None:
            raise RuntimeError("Could not create Telegram user")
        return updated_row

    async def get_balance(self, user_id: int) -> Balance:
        async with self._lock:
            connection = self._require_connection()
            row = await self._ensure_user_locked(user_id, int(time.time()))
            await connection.commit()
            return Balance(
                free_requests=row["free_requests"],
                purchased_requests=row["purchased_requests"],
            )

    async def consume_request(self, user_id: int) -> bool:
        async with self._lock:
            connection = self._require_connection()
            await connection.execute("BEGIN IMMEDIATE")
            row = await self._ensure_user_locked(user_id, int(time.time()))

            if row["free_requests"] > 0:
                await connection.execute(
                    """
                    UPDATE users
                    SET free_requests = free_requests - 1
                    WHERE user_id = ?
                    """,
                    (user_id,),
                )
                consumed = True
            elif row["purchased_requests"] > 0:
                await connection.execute(
                    """
                    UPDATE users
                    SET purchased_requests = purchased_requests - 1
                    WHERE user_id = ?
                    """,
                    (user_id,),
                )
                consumed = True
            else:
                consumed = False

            await connection.commit()
            return consumed

    async def credit_purchase(
        self,
        user_id: int,
        package_id: str,
        requests: int,
        stars: int,
        telegram_payment_charge_id: str,
    ) -> bool:
        """Credit a payment once; duplicate Telegram updates are ignored."""
        if not telegram_payment_charge_id:
            return False

        async with self._lock:
            connection = self._require_connection()
            await connection.execute("BEGIN IMMEDIATE")
            await self._ensure_user_locked(user_id, int(time.time()))

            cursor = await connection.execute(
                """
                INSERT OR IGNORE INTO payments (
                    telegram_payment_charge_id,
                    user_id,
                    package_id,
                    requests,
                    stars,
                    created_at
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    telegram_payment_charge_id,
                    user_id,
                    package_id,
                    requests,
                    stars,
                    int(time.time()),
                ),
            )
            was_inserted = cursor.rowcount == 1
            await cursor.close()

            if was_inserted:
                await connection.execute(
                    """
                    UPDATE users
                    SET purchased_requests = purchased_requests + ?
                    WHERE user_id = ?
                    """,
                    (requests, user_id),
                )

            await connection.commit()
            return was_inserted