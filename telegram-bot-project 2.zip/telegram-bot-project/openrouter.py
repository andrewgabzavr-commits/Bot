import asyncio
from collections.abc import Sequence
from typing import TypedDict

import aiohttp


OPENROUTER_API_URL = "https://openrouter.ai/api/v1/chat/completions"
OPENROUTER_MODEL = "openrouter/free"


class ChatMessage(TypedDict):
    role: str
    content: str


class OpenRouterUnavailable(RuntimeError):
    """The free OpenRouter model cannot answer at the moment."""


async def ask_openrouter(
    messages: Sequence[ChatMessage],
    api_key: str,
) -> str:
    if not api_key:
        raise OpenRouterUnavailable

    payload = {
        "model": OPENROUTER_MODEL,
        "messages": list(messages),
    }
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "X-Title": "Telegram AI Photo Bot",
    }
    timeout = aiohttp.ClientTimeout(total=45)

    try:
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(
                OPENROUTER_API_URL,
                headers=headers,
                json=payload,
            ) as response:
                if response.status != 200:
                    raise OpenRouterUnavailable
                data = await response.json(content_type=None)

        content = data["choices"][0]["message"]["content"]
        if not isinstance(content, str) or not content.strip():
            raise OpenRouterUnavailable
        return content.strip()
    except OpenRouterUnavailable:
        raise
    except (
        aiohttp.ClientError,
        asyncio.TimeoutError,
        KeyError,
        IndexError,
        TypeError,
        ValueError,
    ) as error:
        raise OpenRouterUnavailable from error