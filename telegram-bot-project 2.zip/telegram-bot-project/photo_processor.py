import asyncio
import base64
import logging
import os
from typing import Any

import aiohttp


logger = logging.getLogger(__name__)

GEMINI_API_URL = (
    "https://generativelanguage.googleapis.com/v1beta/models/"
    "{model}:generateContent"
)
# Current Gemini model with image editing support (a.k.a. "Nano Banana 2").
GEMINI_MODEL = "gemini-3.1-flash-image"
GEMINI_TIMEOUT_SECONDS = 60


class PhotoProcessingError(RuntimeError):
    """Base class for all photo-processing failures."""


class AIProcessorNotConfigured(PhotoProcessingError):
    """Raised when GEMINI_API_KEY is not set."""


class GeminiRateLimited(PhotoProcessingError):
    """Raised when Gemini reports a rate limit / quota error (HTTP 429)."""


class GeminiUnavailable(PhotoProcessingError):
    """Raised for transient failures: timeouts, network errors, 5xx, bad payloads."""


class GeminiNoImageReturned(PhotoProcessingError):
    """Raised when Gemini responded successfully but without image data."""


async def process_photo(
    image_bytes: bytes,
    instruction: str,
    *,
    mime_type: str = "image/jpeg",
) -> bytes:
    """Send a photo and an editing instruction to Gemini and return the result.

    Args:
        image_bytes: The raw bytes of the source photo (e.g. downloaded from Telegram).
        instruction: The user's free-form instruction, e.g. "убери человека
            на заднем плане", "измени фон", "улучши фотографию".
        mime_type: MIME type of the source image. Telegram photos are JPEG.

    Returns:
        The raw bytes of the edited image returned by Gemini.

    Raises:
        ValueError: If the input image or instruction is empty.
        AIProcessorNotConfigured: If GEMINI_API_KEY is not set.
        GeminiRateLimited: If Gemini's rate limit / quota was exceeded.
        GeminiUnavailable: On timeouts, network errors, server errors, or
            malformed responses.
        GeminiNoImageReturned: If Gemini answered without returning an image
            (e.g. it refused the request or only returned text).
    """
    if not image_bytes:
        raise ValueError("image_bytes must not be empty")
    if not instruction or not instruction.strip():
        raise ValueError("instruction must not be empty")

    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise AIProcessorNotConfigured("GEMINI_API_KEY is not set.")

    payload = {
        "contents": [
            {
                "role": "user",
                "parts": [
                    {"text": instruction.strip()},
                    {
                        "inline_data": {
                            "mime_type": mime_type,
                            "data": base64.b64encode(image_bytes).decode("ascii"),
                        }
                    },
                ],
            }
        ],
        "generationConfig": {
            "responseModalities": ["TEXT", "IMAGE"],
        },
    }
    headers = {
        "x-goog-api-key": api_key,
        "Content-Type": "application/json",
    }
    url = GEMINI_API_URL.format(model=GEMINI_MODEL)
    timeout = aiohttp.ClientTimeout(total=GEMINI_TIMEOUT_SECONDS)

    try:
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(url, headers=headers, json=payload) as response:
                status = response.status
                data = await response.json(content_type=None)
    except asyncio.TimeoutError as error:
        raise GeminiUnavailable("Gemini request timed out.") from error
    except aiohttp.ClientError as error:
        raise GeminiUnavailable("Gemini network error.") from error

    if status == 429:
        raise GeminiRateLimited("Gemini rate limit or quota exceeded.")
    if status == 401 or status == 403:
        # Never log the key itself, only that auth failed.
        logger.warning("Gemini request rejected: authentication/authorization error")
        raise GeminiUnavailable("Gemini rejected the request (auth error).")
    if status >= 500:
        raise GeminiUnavailable(f"Gemini server error: {status}")
    if status != 200:
        logger.warning(
            "Gemini request failed: status=%s message=%s",
            status,
            _extract_error_message(data),
        )
        raise GeminiUnavailable(f"Gemini request failed with status {status}")

    image_data = _extract_image_bytes(data)
    if image_data is None:
        raise GeminiNoImageReturned("Gemini response did not include an image.")
    return image_data


def _extract_error_message(data: Any) -> str:
    try:
        return str(data.get("error", {}).get("message", ""))
    except AttributeError:
        return ""


def _extract_image_bytes(data: Any) -> bytes | None:
    try:
        candidates = data["candidates"]
    except (KeyError, TypeError):
        return None

    for candidate in candidates:
        parts = (candidate.get("content") or {}).get("parts", [])
        for part in parts:
            inline_data = part.get("inline_data") or part.get("inlineData")
            if inline_data and inline_data.get("data"):
                try:
                    return base64.b64decode(inline_data["data"])
                except (ValueError, TypeError):
                    continue
    return None
