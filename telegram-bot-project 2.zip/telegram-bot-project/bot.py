import asyncio
import html
import logging
import os
from dataclasses import dataclass

from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    BotCommand,
    BufferedInputFile,
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    LabeledPrice,
    Message,
    PreCheckoutQuery,
    ReplyKeyboardMarkup,
)

from database import Balance, Database
from openrouter import (
    ChatMessage,
    OpenRouterUnavailable,
    ask_openrouter,
)
from photo_processor import (
    AIProcessorNotConfigured,
    GeminiNoImageReturned,
    GeminiRateLimited,
    GeminiUnavailable,
    process_photo,
)


TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")
DATABASE_PATH = os.getenv("BOT_DATABASE_PATH", "data/bot.sqlite3")

if not TOKEN:
    raise RuntimeError(
        "TELEGRAM_BOT_TOKEN is not set. Add it to the project secrets."
    )


@dataclass(frozen=True)
class PurchasePackage:
    package_id: str
    requests: int
    stars: int
    button_text: str


PACKAGES: dict[str, PurchasePackage] = {
    "20": PurchasePackage("20", 20, 200, "20 запр. • ⭐ 200"),
    "50": PurchasePackage("50", 50, 400, "50 запр. • ⭐ 400"),
    "200": PurchasePackage("200", 200, 1400, "200 запр. • ⭐ 1400"),
    "500": PurchasePackage("500", 500, 3000, "500 запр. • ⭐ 3000"),
    "1000": PurchasePackage("1000", 1_000, 5000, "1,000 запр. • ⭐ 5000"),
    "3000": PurchasePackage("3000", 3_000, 12000, "3,000 запр. • ⭐ 12000"),
    "20000": PurchasePackage(
        "20000",
        20_000,
        60000,
        "🔥 Выгодный • 20,000 запр. • ⭐ 60000",
    ),
}


MAIN_MENU = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="📸 Обработать фото"),
            KeyboardButton(text="⭐ Купить запросы"),
        ],
        [
            KeyboardButton(text="💬 Общение с AI"),
            KeyboardButton(text="📊 Мой баланс"),
        ],
        [
            KeyboardButton(text="❓ Помощь"),
        ],
    ],
    resize_keyboard=True,
    is_persistent=True,
)

AI_CHAT_MENU = ReplyKeyboardMarkup(
    keyboard=[[KeyboardButton(text="🔙 Назад")]],
    resize_keyboard=True,
    is_persistent=True,
)

AI_UNAVAILABLE_TEXT = (
    "⚠️ Бесплатный AI сейчас временно недоступен. Попробуйте позже."
)
AI_MAX_HISTORY_MESSAGES = 12
active_ai_users: set[int] = set()
ai_chat_history: dict[int, list[ChatMessage]] = {}

# Maps user_id -> file_id of a photo awaiting a text instruction. Holds only
# a Telegram file_id (a reference), never photo bytes, and never touches disk.
pending_photo_instruction: dict[int, str] = {}


def purchase_menu() -> InlineKeyboardMarkup:
    rows = [
        ("20", "50"),
        ("200", "500"),
        ("1000", "3000"),
        ("20000",),
    ]
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=PACKAGES[package_id].button_text,
                    callback_data=f"buy:{package_id}",
                )
                for package_id in row
            ]
            for row in rows
        ]
        + [
            [
                InlineKeyboardButton(
                    text="‹ Назад",
                    callback_data="menu:back",
                )
            ]
        ]
    )


def purchase_menu_text() -> str:
    return (
        "🔎 Выбери тариф, как настоящий сыщик:\n\n"
        "Чем больше пакет — тем дешевле\n"
        "каждый запрос. Экономия до 70%."
    )


def balance_text(balance: Balance) -> str:
    return (
        "📊 <b>Мой баланс</b>\n\n"
        f"Бесплатные запросы: <b>{balance.free_requests}</b>\n"
        f"Купленные запросы: <b>{balance.purchased_requests}</b>\n"
        f"Всего доступно: <b>{balance.total_requests}</b>"
    )


def split_message(text: str, max_length: int = 4000) -> list[str]:
    return [
        text[index : index + max_length]
        for index in range(0, len(text), max_length)
    ] or [""]


async def answer_in_chunks(
    message: Message,
    text: str,
    reply_markup: ReplyKeyboardMarkup,
) -> None:
    chunks = split_message(text)
    for index, chunk in enumerate(chunks):
        await message.answer(
            chunk,
            reply_markup=reply_markup if index == len(chunks) - 1 else None,
        )


async def show_purchase_menu(message: Message) -> None:
    await message.answer(
        purchase_menu_text(),
        reply_markup=purchase_menu(),
    )


dispatcher = Dispatcher()


@dispatcher.message(CommandStart())
async def handle_start(message: Message, db: Database) -> None:
    if message.from_user is None:
        return

    active_ai_users.discard(message.from_user.id)
    ai_chat_history.pop(message.from_user.id, None)
    pending_photo_instruction.pop(message.from_user.id, None)
    await db.get_balance(message.from_user.id)
    await message.answer(
        "Привет! Я помогу обработать фотографию с помощью AI.\n\n"
        "Каждый день тебе доступны 3 бесплатных запроса. "
        "Дополнительные запросы можно купить за Telegram Stars.",
        reply_markup=MAIN_MENU,
    )


@dispatcher.message(Command("help"))
@dispatcher.message(F.text == "❓ Помощь")
async def handle_help(message: Message) -> None:
    await message.answer(
        "<b>Как это работает</b>\n\n"
        "1. Нажми «📸 Обработать фото».\n"
        "2. Отправь фотографию.\n"
        "3. Один успешный запуск обработки списывает один запрос.\n\n"
        "Каждые 24 часа возвращаются 3 бесплатных запроса. "
        "Купленные запросы не сгорают.",
        reply_markup=MAIN_MENU,
    )


@dispatcher.message(Command("balance"))
@dispatcher.message(F.text == "📊 Мой баланс")
async def handle_balance(message: Message, db: Database) -> None:
    if message.from_user is None:
        return

    balance = await db.get_balance(message.from_user.id)
    await message.answer(balance_text(balance), reply_markup=MAIN_MENU)


@dispatcher.message(Command("buy"))
@dispatcher.message(F.text == "⭐ Купить запросы")
async def handle_buy(message: Message) -> None:
    await show_purchase_menu(message)


@dispatcher.message(F.text == "📸 Обработать фото")
async def handle_process_button(message: Message) -> None:
    await message.answer(
        "Отправь фотографию следующим сообщением — я проверю доступный баланс "
        "и передам её в AI-модуль.",
        reply_markup=MAIN_MENU,
    )


@dispatcher.message(F.text == "💬 Общение с AI")
async def handle_ai_chat_button(message: Message) -> None:
    if message.from_user is None:
        return

    active_ai_users.add(message.from_user.id)
    ai_chat_history[message.from_user.id] = []
    pending_photo_instruction.pop(message.from_user.id, None)
    await message.answer(
        "💬 Режим общения с AI включён.\n\n"
        "Напиши сообщение, и я передам его бесплатной модели OpenRouter. "
        "Telegram Stars и запросы на обработку фотографий здесь не списываются.",
        reply_markup=AI_CHAT_MENU,
    )


@dispatcher.message(F.text == "🔙 Назад")
async def handle_ai_chat_back(message: Message) -> None:
    if message.from_user is not None:
        active_ai_users.discard(message.from_user.id)
        ai_chat_history.pop(message.from_user.id, None)
        pending_photo_instruction.pop(message.from_user.id, None)
    await message.answer("Главное меню:", reply_markup=MAIN_MENU)


async def run_photo_processing(
    message: Message,
    db: Database,
    bot: Bot,
    user_id: int,
    file_id: str,
    instruction: str,
) -> None:
    """Download the photo, send it to Gemini, charge on success only.

    The photo is kept purely in memory (an in-memory buffer and a bytes
    object) for the duration of this call and is never written to disk.
    """
    status_message = await message.answer("🛠 Обрабатываю фото…")

    try:
        file_buffer = await bot.download(file_id)
        image_bytes = file_buffer.read()
        result_bytes = await process_photo(image_bytes, instruction)
    except AIProcessorNotConfigured:
        await status_message.delete()
        await message.answer(
            "⚠️ AI-модуль обработки фото ещё не настроен на сервере. "
            "Запрос не списан.",
            reply_markup=MAIN_MENU,
        )
        return
    except GeminiRateLimited:
        await status_message.delete()
        await message.answer(
            "⏳ Сервис обработки фото сейчас перегружен (превышен лимит "
            "запросов). Попробуй через пару минут. Запрос не списан.",
            reply_markup=MAIN_MENU,
        )
        return
    except GeminiUnavailable:
        await status_message.delete()
        await message.answer(
            "⚠️ Не удалось обработать фото — сервис временно недоступен. "
            "Попробуй ещё раз чуть позже. Запрос не списан.",
            reply_markup=MAIN_MENU,
        )
        return
    except GeminiNoImageReturned:
        await status_message.delete()
        await message.answer(
            "🤔 AI не смог выполнить эту правку и не вернул изображение. "
            "Попробуй переформулировать инструкцию. Запрос не списан.",
            reply_markup=MAIN_MENU,
        )
        return
    except ValueError:
        await status_message.delete()
        await message.answer(
            "Не получилось прочитать фото или инструкцию. Попробуй ещё раз. "
            "Запрос не списан.",
            reply_markup=MAIN_MENU,
        )
        return
    except Exception:
        logging.exception(
            "Unexpected error while processing a photo for user %s", user_id
        )
        await status_message.delete()
        await message.answer(
            "⚠️ Произошла непредвиденная ошибка при обработке фото. "
            "Запрос не списан.",
            reply_markup=MAIN_MENU,
        )
        return

    consumed = await db.consume_request(user_id)
    await status_message.delete()

    if not consumed:
        # Balance ran out between the initial check and now (e.g. a race
        # with another request) — do not lose the already-processed image
        # silently, but make clear nothing further can be charged.
        await message.answer(
            "Свободные и купленные запросы закончились. Выбери пакет для покупки:",
            reply_markup=MAIN_MENU,
        )
        await show_purchase_menu(message)
        return

    await message.answer_photo(
        BufferedInputFile(result_bytes, filename="result.jpg"),
        caption="Готово! ✅",
        reply_markup=MAIN_MENU,
    )


@dispatcher.message(F.photo)
async def handle_photo(message: Message, db: Database, bot: Bot) -> None:
    if message.from_user is None:
        return

    user_id = message.from_user.id

    balance = await db.get_balance(user_id)
    if balance.total_requests == 0:
        pending_photo_instruction.pop(user_id, None)
        await message.answer(
            "Свободные и купленные запросы закончились. Выбери пакет для покупки:",
            reply_markup=MAIN_MENU,
        )
        await show_purchase_menu(message)
        return

    file_id = message.photo[-1].file_id
    instruction = (message.caption or "").strip()

    if instruction:
        pending_photo_instruction.pop(user_id, None)
        await run_photo_processing(message, db, bot, user_id, file_id, instruction)
        return

    pending_photo_instruction[user_id] = file_id
    await message.answer(
        "Напиши, что нужно изменить на фото ✏️",
        reply_markup=MAIN_MENU,
    )


def is_awaiting_photo_instruction(message: Message) -> bool:
    return (
        message.from_user is not None
        and bool(message.text)
        and message.from_user.id in pending_photo_instruction
    )


@dispatcher.message(is_awaiting_photo_instruction)
async def handle_photo_instruction(message: Message, db: Database, bot: Bot) -> None:
    if message.from_user is None or not message.text:
        return

    user_id = message.from_user.id
    file_id = pending_photo_instruction.pop(user_id, None)
    if file_id is None:
        return

    instruction = message.text.strip()
    if not instruction:
        pending_photo_instruction[user_id] = file_id
        await message.answer(
            "Напиши, что нужно изменить на фото ✏️",
            reply_markup=MAIN_MENU,
        )
        return

    # Re-check the balance: time may have passed since the photo arrived.
    balance = await db.get_balance(user_id)
    if balance.total_requests == 0:
        await message.answer(
            "Свободные и купленные запросы закончились. Выбери пакет для покупки:",
            reply_markup=MAIN_MENU,
        )
        await show_purchase_menu(message)
        return

    await run_photo_processing(message, db, bot, user_id, file_id, instruction)


@dispatcher.callback_query(F.data.startswith("buy:"))
async def handle_buy_callback(
    callback: CallbackQuery,
    bot: Bot,
) -> None:
    package_id = callback.data.split(":", maxsplit=1)[1]
    package = PACKAGES.get(package_id)
    if package is None:
        await callback.answer("Тариф не найден.", show_alert=True)
        return

    await callback.answer()
    await bot.send_invoice(
        chat_id=callback.from_user.id,
        title=f"Пакет на {package.requests:,} запросов",
        description=(
            f"Дополнительные запросы для AI-обработки фотографий. "
            f"Пакет: {package.requests:,} запросов."
        ),
        payload=f"purchase:{package.package_id}",
        currency="XTR",
        prices=[
            LabeledPrice(
                label=f"{package.requests:,} запросов",
                amount=package.stars,
            )
        ],
        provider_token="",
        start_parameter=f"purchase_{package.package_id}",
    )


@dispatcher.callback_query(F.data == "menu:back")
async def handle_back_to_main_menu(callback: CallbackQuery) -> None:
    await callback.answer()
    if callback.message is not None:
        await callback.message.delete()
        await callback.message.answer(
            "Главное меню:",
            reply_markup=MAIN_MENU,
        )


@dispatcher.pre_checkout_query()
async def handle_pre_checkout_query(query: PreCheckoutQuery) -> None:
    try:
        prefix, package_id = query.invoice_payload.split(":", maxsplit=1)
        package = PACKAGES.get(package_id) if prefix == "purchase" else None
    except ValueError:
        package = None

    if (
        package is None
        or query.currency != "XTR"
        or query.total_amount != package.stars
    ):
        await query.answer(
            ok=False,
            error_message="Не удалось проверить тариф. Попробуй оформить покупку заново.",
        )
        return

    await query.answer(ok=True)


@dispatcher.message(F.successful_payment)
async def handle_successful_payment(message: Message, db: Database) -> None:
    payment = message.successful_payment
    if payment is None or message.from_user is None:
        return

    try:
        prefix, package_id = payment.invoice_payload.split(":", maxsplit=1)
        package = PACKAGES.get(package_id) if prefix == "purchase" else None
    except ValueError:
        package = None

    if (
        package is None
        or payment.currency != "XTR"
        or payment.total_amount != package.stars
    ):
        logging.error("Rejected invalid successful payment payload")
        return

    credited = await db.credit_purchase(
        user_id=message.from_user.id,
        package_id=package.package_id,
        requests=package.requests,
        stars=package.stars,
        telegram_payment_charge_id=payment.telegram_payment_charge_id,
    )
    if not credited:
        await message.answer(
            "Этот платёж уже был учтён ранее.",
            reply_markup=MAIN_MENU,
        )
        return

    balance = await db.get_balance(message.from_user.id)
    await message.answer(
        f"Оплата подтверждена. Начислено запросов: "
        f"<b>{package.requests:,}</b>.\n\n{balance_text(balance)}",
        reply_markup=MAIN_MENU,
    )


@dispatcher.message()
async def handle_unknown_message(message: Message) -> None:
    if (
        message.from_user is not None
        and message.text
        and message.from_user.id in active_ai_users
    ):
        user_id = message.from_user.id
        history = ai_chat_history.setdefault(user_id, [])
        history.append({"role": "user", "content": message.text})
        history[:] = history[-AI_MAX_HISTORY_MESSAGES:]

        if not OPENROUTER_API_KEY:
            history.pop()
            await message.answer(
                AI_UNAVAILABLE_TEXT,
                reply_markup=AI_CHAT_MENU,
            )
            return

        try:
            response = await ask_openrouter(
                history,
                OPENROUTER_API_KEY,
            )
        except OpenRouterUnavailable:
            history.pop()
            await message.answer(
                AI_UNAVAILABLE_TEXT,
                reply_markup=AI_CHAT_MENU,
            )
            return

        history.append({"role": "assistant", "content": response})
        history[:] = history[-AI_MAX_HISTORY_MESSAGES:]
        await answer_in_chunks(
            message,
            html.escape(response),
            AI_CHAT_MENU,
        )
        return

    await message.answer(
        "Выбери действие в меню ниже.",
        reply_markup=MAIN_MENU,
    )


async def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
    )

    database = Database(DATABASE_PATH)
    await database.connect()

    bot = Bot(
        token=TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    await bot.set_my_commands(
        [
            BotCommand(command="start", description="Главное меню"),
            BotCommand(command="buy", description="Купить запросы"),
            BotCommand(command="balance", description="Мой баланс"),
            BotCommand(command="help", description="Помощь"),
        ]
    )

    try:
        await bot.delete_webhook(drop_pending_updates=False)
        logging.info("Bot is running. Press Ctrl+C to stop.")
        await dispatcher.start_polling(bot, db=database)
    finally:
        await database.close()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())